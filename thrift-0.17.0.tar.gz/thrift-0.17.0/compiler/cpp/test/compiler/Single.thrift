const string foo = "bar"
