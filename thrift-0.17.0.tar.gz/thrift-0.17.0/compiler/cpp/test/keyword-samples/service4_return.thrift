exception exception_name {}

service service_name {
  void function_name() throws ( 1: exception_name return)
}
